# Kiosk Screen Setup Scripts

Standalone scripts to turn any PC into a kiosk screen that VR HEADSET MANAGER
(VRHM) can discover on the LAN and remote-control via the Chrome DevTools
Protocol (CDP). Copy the file matching your kiosk's OS onto that PC and run it
there - none of these scripts depends on any other file from this project.

There are two tiers. **Casting works identically in both**; the advanced tier
adds reporting and remote power control.

| Script | Platform | Tier |
|---|---|---|
| `Start-KioskAgent.ps1` | Windows (Google Chrome) | **Advanced - recommended** |
| `Start-KioskAgent-Linux.sh` | Debian / Raspberry Pi OS (Chromium) | **Advanced - recommended** |
| `Start-KioskChrome.ps1` | Windows (Google Chrome) | Basic |
| `Start-KioskChrome-Linux.sh` | Debian / Raspberry Pi OS (Chromium) | Basic |

What the advanced tier adds over the basic one:

- **Device reporting** - the kiosk tells VRHM its computer name, OS version,
  browser version, and whether it is talking to the server over **Ethernet or
  WiFi** (with link speed). All of it shows up in the Kiosk Screens table and
  in the network scan.
- **Remote power control** - reboot or shut the kiosk PC down from VRHM's web
  UI or from the console `[K]` menu.
- **Browser watchdog** - if the browser crashes or is closed, it is relaunched
  automatically. "Kill kiosk browser" therefore becomes a *restart* on an
  advanced kiosk instead of leaving the screen dark until someone walks over
  to it.

**The advanced scripts never open a listening port.** They only make outbound
calls: to their own loopback debug port, and to the VRHM server. Operator
commands travel back inside the reply to the kiosk's own status report, so no
inbound firewall rule beyond the existing debug port is needed.

The trade-off is that an advanced script must **keep running** - it is the
agent. Leave its window open, or set it up to autostart (see below).

All four scripts do the same four things, adapted to their platform:

1. Make sure they have the privileges they need (Windows: self-elevate to
   Administrator; Linux: ask for `sudo` only for the specific commands that
   need it - firewall rules and, if needed, the socat relay - never for
   launching the browser itself).
2. Open the firewall for the Chrome/Chromium remote debugging port (default
   `9222`).
3. Launch the browser in kiosk mode with remote debugging enabled, pointed
   at a start URL.
4. Verify the debug port actually became reachable from the LAN, and if the
   browser silently refused to bind anything other than `127.0.0.1` (see
   "Why the port forward trick is needed" below), automatically set up an
   OS-level relay so VRHM can still reach it.

They are all safe to re-run at any time (after a reboot, to change the URL,
etc). Any previous kiosk browser instance and any previous port relay on the
same port are stopped first.

---

## Windows: the ready-to-use package (easiest)

For a Windows kiosk you do not need any of the command lines below. In VRHM open
**Kiosk Screens -> Add kiosk device -> Setup Scripts** and download
**`VRHM-Kiosk-Setup.zip`**. Unzip it anywhere on the kiosk PC and double-click:

| File | What it does |
|---|---|
| `Start-Kiosk-ADVANCED.cmd` | Asks for administrator rights, then starts the kiosk browser **and** the reporting agent, already pointed at your VRHM server. |
| `Start-Kiosk-BASIC.cmd` | Asks for administrator rights, then runs the original casting-only launcher. The fallback if the advanced one gives trouble on a particular PC. |

The server address is baked into `Start-Kiosk-ADVANCED.cmd` when the package is
built, and **VRHM rebuilds the package every time the application starts** - so
if the server's IP changes, just download it again. To point a copy at a
different server without re-downloading, pass the address:

```bat
Start-Kiosk-ADVANCED.cmd 192.168.1.50
Start-Kiosk-ADVANCED.cmd http://192.168.1.50:8080
```

The zip also contains both `.ps1` launchers and this README, so everything you
might need is in one place.

---

## The advanced launcher (manual setup)

Use this for Linux, or on Windows if you would rather run the script directly.

The one thing worth getting right is `-ServerUrl` / `--server-url`: it is the
address of the VRHM server, and it is what lets the kiosk report itself. VRHM's
Kiosk Screens page hands you a ready-to-paste command line with it already
filled in - open **Add kiosk device -> Setup Scripts** and use the copy button.

Running `Start-KioskAgent.ps1` with **no parameters at all** is safe: it behaves
like the basic launcher (casting works, reporting and power control do not)
until it either learns the server address from a pushed URL or is given one.

### Windows

```powershell
.\Start-KioskAgent.ps1 -ServerUrl "http://192.168.1.37:8080"
.\Start-KioskAgent.ps1 -ServerUrl "http://192.168.1.37:8080" -Port 9222 -ReportIntervalSec 10
```

Same auto-elevation, Chrome auto-detection and `-ChromePath` /`-Url` /`-Port`
options as the basic script. Additional options:

| Option | Meaning |
|---|---|
| `-ServerUrl` | VRHM server base URL. Without it the kiosk cannot report until it learns the address from the first URL pushed to it. |
| `-ReportIntervalSec` | How often to report (default `5`). Also bounds how long a reboot order takes to arrive. |
| `-NoAutoRestartBrowser` | Do not relaunch the browser when it exits (the script then quits too, like the basic launcher). |

Reboot and shutdown run inside the already-elevated script, so Windows needs no
extra privilege setup.

To start it at boot, create a Scheduled Task running as the kiosk user with
"Run with highest privileges" and trigger "At log on", pointing at:

```
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\path\to\Start-KioskAgent.ps1" -ServerUrl "http://192.168.1.37:8080"
```

### Debian / Raspberry Pi OS

```bash
chmod +x Start-KioskAgent-Linux.sh
./Start-KioskAgent-Linux.sh --server-url "http://192.168.1.37:8080"
```

Options: `--server-url`, `--url`, `--port`, `--report-interval`,
`--no-auto-restart`. Positional `URL PORT` also works, matching the basic
script. `curl` is required and offered for install if missing.

Unlike the basic Linux script, **this one stays in the foreground** - that is
the agent loop. Closing the terminal stops the reporting and the watchdog.

**Reboot and shutdown need root on Linux.** Either run the script under `sudo`,
or grant the kiosk user passwordless rights to just those commands
(`sudo visudo -f /etc/sudoers.d/vrhm-kiosk-power`):

```
pi ALL=(root) NOPASSWD: /usr/bin/systemctl reboot, /usr/bin/systemctl poweroff, /sbin/shutdown
```

(replace `pi` with your kiosk user; check the real paths with
`which systemctl shutdown` first). Without this, casting and reporting still
work perfectly - only the power buttons fail, with a message in the terminal.

To run it at boot as a proper service, create
`/etc/systemd/system/vrhm-kiosk.service`:

```ini
[Unit]
Description=VRHM Kiosk Agent
After=graphical.target network-online.target

[Service]
Type=simple
User=pi
Environment=DISPLAY=:0
Environment=XAUTHORITY=/home/pi/.Xauthority
ExecStart=/home/pi/Start-KioskAgent-Linux.sh --server-url http://192.168.1.37:8080
Restart=always
RestartSec=10

[Install]
WantedBy=graphical.target
```

then `sudo systemctl daemon-reload && sudo systemctl enable --now vrhm-kiosk`.
Adjust the user, paths and server URL. `Restart=always` means the agent itself
comes back if it ever exits, which together with its own browser watchdog makes
the kiosk self-healing across both crashes and reboots.

---

## The basic launcher

Use this when you only need casting and would rather not leave a script
running. The kiosk will show a `-` in the Device column and its power buttons
stay disabled.

## Windows

```powershell
.\Start-KioskChrome.ps1
.\Start-KioskChrome.ps1 -Url "https://example.com" -Port 9222
```

Double-click also works - the script self-elevates automatically and shows a
UAC prompt if it wasn't started as Administrator.

Requires Google Chrome to be installed. The script auto-detects it under
`Program Files`, `Program Files (x86)`, the per-user install location, or
the Windows "App Paths" registry key; use `-ChromePath` to point at a custom
install location if needed.

---

## Debian / Raspberry Pi OS (Raspbian)

```bash
chmod +x Start-KioskChrome-Linux.sh
./Start-KioskChrome-Linux.sh
./Start-KioskChrome-Linux.sh "https://example.com" 9222
```

**Run it as your normal desktop user, from a terminal inside the kiosk's own
graphical session** (not as `root`, and not over a plain SSH session without
X forwarding) - the script needs a `DISPLAY` to open the browser window, and
Chromium refuses to run as `root` without `--no-sandbox` (which the script
does not use, since it weakens the sandbox). If you do run the script with
`sudo`, it detects this via `$SUDO_USER` and launches Chromium back under
your normal account automatically, so this is only a concern if you're
running the script as a bare `root` shell with no other user to fall back
to.

Requires Chromium to be installed:

```bash
sudo apt-get update
sudo apt-get install -y chromium
```

(older Raspberry Pi OS releases before the 2023 Debian Bookworm rebase use
the package name `chromium-browser` instead of `chromium` - the script
checks for both automatically, along with `google-chrome`/
`google-chrome-stable` in case you installed Google's own build).

### Auto-starting on boot (recommended for a real kiosk deployment)

Once the script works when run manually, add it to your desktop
environment's autostart so the kiosk comes back up on its own after a power
cycle. For the default Raspberry Pi OS desktop (LXDE / PIXEL, or the newer
Wayfire/labwc session on Bookworm), create:

```
~/.config/autostart/vrhm-kiosk.desktop
```

with contents:

```ini
[Desktop Entry]
Type=Application
Name=VRHM Kiosk Chrome
Exec=/home/pi/Start-KioskChrome-Linux.sh "about:blank" 9222
X-GNOME-Autostart-enabled=true
```

(adjust the path to wherever you copied the script, and enable auto-login
for the kiosk user in `raspi-config` so the desktop session actually starts
without anyone needing to log in manually).

If your firewall or the socat fallback step prompts for a `sudo` password on
every boot, that will block unattended autostart. Grant passwordless `sudo`
for just the specific commands the script runs, by adding a file under
`/etc/sudoers.d/` (edit with `sudo visudo -f /etc/sudoers.d/vrhm-kiosk`):

```
pi ALL=(root) NOPASSWD: /usr/sbin/iptables, /usr/sbin/ufw, /usr/bin/firewall-cmd, /usr/bin/apt-get
```

(replace `pi` with your actual kiosk user, and drop any tools you aren't
using - check with `which iptables ufw firewall-cmd apt-get` first, since
not all of them are usually installed at once).

---

## Why the port-forward / port-relay trick is needed

Modern Chrome and Chromium intentionally ignore the
`--remote-debugging-address` flag and hard-lock the DevTools remote
debugging listener to `127.0.0.1` (loopback) only, regardless of what
address you pass. This was a deliberate security change - see
[Chromium issue 40242234](https://issues.chromium.org/issues/40242234) - the
project's own reasoning being that "unprotected remote access to CDP was
considered too dangerous" to keep exposing via a simple command-line flag.

Because of this, opening the firewall alone does nothing: nothing is
actually listening on the kiosk's real network interface, only on loopback.
Both scripts detect this after launching the browser and, if the debug port
turns out to be loopback-only, set up an OS-level relay that forwards the
kiosk's real IP address on the debug port straight through to the browser's
loopback listener:

- **Windows**: `netsh interface portproxy add v4tov4 ...`
- **Linux**: an `iptables` NAT rule
  (`-t nat -A PREROUTING ... -j DNAT --to-destination 127.0.0.1:<port>`,
  tagged with the comment `VRHM_KIOSK_DEBUGPORT`), plus
  `net.ipv4.conf.*.route_localnet=1` so the kernel stops treating the
  redirected packets as martian. Nothing extra needs installing - this uses
  the same netfilter stack as the firewall step above. Older versions of these
  scripts used a `socat` relay instead; any leftover `socat` process on the
  port is cleaned up automatically.

This is transparent to VRHM - it just sees the debug port open on the
kiosk's real IP, whether that's because the browser itself bound it
directly (older versions) or because of the relay (current versions).

---

## Troubleshooting

If VRHM's Kiosk Screens scan still doesn't find the kiosk after running the
script:

1. Confirm the browser process is actually running with the expected flags
   and check what address it bound:
   - Windows: `netstat -ano | findstr :9222` and
     `Get-CimInstance Win32_Process -Filter "Name='chrome.exe'" | Where-Object { $_.CommandLine -like '*9222*' } | Select-Object ProcessId, CommandLine`
   - Linux: `ss -ltnp | grep 9222` and `pgrep -af "remote-debugging-port"`
2. If it's bound to `127.0.0.1` only, confirm the relay is running:
   - Windows: `netsh interface portproxy show v4tov4`
   - Linux: `pgrep -af socat`
3. Test reachability from the VRHM server itself (adjust the IP/port):
   - `Test-NetConnection -ComputerName <kiosk-ip> -Port 9222` (from the VRHM
     server, if it's Windows)
4. Make sure nothing else on the kiosk (a stricter local firewall profile,
   an EDR/antivirus product, or a router with client isolation between
   Wi-Fi and Ethernet devices) is blocking the port at a layer neither
   script can see or control.

### The advanced launcher runs, but the Device column stays empty

The kiosk is not reaching the server. Casting is unaffected, because that
travels the other way (server -> kiosk over CDP).

1. Check the agent's own window - it prints
   `Cannot reach the VR HEADSET MANAGER server at ...` when a report fails,
   and `Reporting to ... restored.` when it recovers.
2. Confirm the URL you passed is the one the kiosk can actually reach. It must
   be the server's **LAN address**, not `localhost` (that would resolve to the
   kiosk itself). Copy it from the Kiosk Screens launcher panel to be sure.
3. From the kiosk, test it directly:
   - Windows: `Invoke-RestMethod "http://<server-ip>:<port>/api/kiosks"`
   - Linux: `curl -s "http://<server-ip>:<port>/api/kiosks"`
4. Reports can time out while the server is busy with a long request (a network
   scan, for example) - the agent simply retries on the next tick, so a brief
   warning during a scan is expected and harmless.
5. A kiosk that reported and then stopped shows its last known values marked
   `(stale)` rather than disappearing, so you can tell "never reported" from
   "stopped reporting".

### Reboot / shutdown does nothing

- The buttons only apply to advanced kiosks. A basic kiosk has no agent to
  receive the order, and its buttons stay disabled.
- On Linux, check the agent window for the passwordless-`sudo` message and add
  the `/etc/sudoers.d/vrhm-kiosk-power` entry shown earlier.
- Orders expire after 5 minutes. If a kiosk was powered off when you sent one,
  it is discarded rather than delivered late - deliberately, so a kiosk cannot
  reboot itself again the moment it comes back.
